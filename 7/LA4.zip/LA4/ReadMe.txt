Read Me:

1) Copy the student's program inside the folder.

2) Execute the following command
	bash execute.sh gcc FILE_NAME.c
		OR
	bash execute.sh g++ FILE_NAME.cpp

3) If there is any difference in the actual and expected output, it will be displayed in the screeen.

4) In case of perfect output, screen will be empty.
